# Complete-HTML-
&lt;!DOCTYPE html> &lt;html>   &lt;head>     &lt;title>My Page&lt;/title>   &lt;/head>   &lt;body>     &lt;h1>Welcome to my page&lt;/h1>     &lt;p>This is a paragraph.&lt;/p>     &lt;ul>       &lt;li>Item 1&lt;/li>       &lt;li>Item 2&lt;/li>       &lt;li>Item 3&lt;/li>     &lt;/ul>   &lt;/body> &lt;/html>
